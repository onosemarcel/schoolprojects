#include<fstream>
#include<iostream>
using namespace std;

int main()
{ int n,A[100][100];
int x=0;

    fstream f;
    f.open("input.dat",ios::in);

    f>>n;
    for(int i=0;i<n;i++)
    for(int j=0;j<n;j++)
        f>>A[i][j];

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(A[i][j]==1) x++;
        }
        cout<<x<<" ";
         for(int j=0;j<n;j++)
        {
            if(A[i][j]==1) cout<<j+1<<" ";
        }
        for(int j=0;j<n-x-1;j++) cout<<0<<" ";
         cout<<endl;
         x=0;
    }
}
