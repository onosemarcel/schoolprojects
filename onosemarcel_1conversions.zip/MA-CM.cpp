#include<iostream>
#include<fstream>
using namespace std;

int A[30][30], i, j, n;
ifstream f("input.dat");

int main()
{
    f>>n;
    for(i=0; i<n; i++)
        for(j=0; j<n; j++)
            f>>A[i][j];
    for(i=0; i<n; i++)
    {
        for(j=0; j<n; j++)
            if(A[i][j] && i<j) cout<<i+1<<" "<<j+1<<endl;
    }
}
