#include <iostream>
#include <fstream>
using namespace std;

ifstream f("input.dat");

int n, p, q, y=0;
int A[100][100];
int cont;
int main()
{
    f>>n;
    f>>cont;
    f>>p>>q;
    while(y<cont)
    {
        A[p][q]=1;
        A[q][p]=1;
        f>>p>>q;
        y++;
    }
    cout<<n<<endl;
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
            cout<<A[i][j]<<" ";
        cout<<endl;
    }
}
