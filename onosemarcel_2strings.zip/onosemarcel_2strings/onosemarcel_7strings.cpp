#include <iostream>
#include <string.h>

using namespace std;

int main() {
    char s[256], cuvant[256], *p;
    int nrAparitii = 0;

    cin.get(s, 256);
    cout<<"Cuvantul cautat";
    cin >> cuvant;

    int cuvantLength = strlen(cuvant);

    for (int i = 0; i < cuvantLength; i++) {
        cuvant[i] = tolower(cuvant[i]);
    }

    p = strstr(s, cuvant);

    while (p) {
        nrAparitii++;
        strcpy(p, p + cuvantLength);
        p = strstr(p, cuvant);
    }

    cout << nrAparitii;

    return 0;
}
