#include<iostream>
#include<strings.h>

using namespace std;

int main()
{
    char sir[256];
    cin.get(sir, 256);
    int k=0;

    for(int i=0; i<strlen(sir); i++)
    {
        if(isspace(sir[i])) k++;
        if(sir[i]=='.')     k++;
    }

    cout<<"Numar de cuvinte "<<k;
}
