#include <iostream>
#include <string.h>

using namespace std;

int main() {
    int n;
    cin >> n;
    cout << endl;

    char s[n][25];

    for (int i = 0; i < n; i++) {
        cin >> s[i];
    }

    for (int i = 0; i < n; i++) {
        for (int j = (i+1); j < n; j++) {
            if (strcmp(s[i], s[j]) > 0) {
                swap(s[i], s[j]);
            }
        }
    }

    for (int i = 0; i < n; i++) {
        cout << s[i] << " ";
    }

    return 0;
}
