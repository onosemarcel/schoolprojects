#include<iostream>
#include<stdio.h>
#include<string.h>
#include<string>
#include<strings.h>
using namespace std;

int main()
{
    char a[100]; char b[100]={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
    char c[100];
    cout<<"a=";
    gets(a);
    int x=97;
    for(int i=0;i<strlen(b);i++)
        {
            c[i]=char(x);
            x=x+2;
            if(x==127) x=33;
        }
    c[strlen(b)]=0;
    for(int i=0;i<strlen(a);i++)
    {
        for(int j=0;j<strlen(b);j++)
        {
            if(a[i]==b[j])
            {
                a[i]=c[j];
                break;
            }
        }
    }
   cout<<a;
}
