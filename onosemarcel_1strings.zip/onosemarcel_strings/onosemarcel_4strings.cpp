#include<iostream>
#include<string.h>
using namespace std;
char sir[30],*p, car;
int nr;
int main()
{
   cout<<"Introduceti sirul: ";
   cin.get(sir,30);
   cout<<"Litera cautata este ";
   cin>>car;
   p=strchr(sir,car);
   cout<<"Litera "<<car<<" apare in: "<<endl;
   while(p)
   {
       nr++;
       cout<<"pozitia "<<p-sir+1<<endl;
       p=strchr(p+1, car);
   }
   cout<<"de "<<nr<<" ori";
}


