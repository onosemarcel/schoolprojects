#include<iostream>
#include<string.h>

using namespace std;
char sir[30],copie_sir[30];
int main()
{
   cin.get(sir,30);
   cout<<"Cuvantul dat "<<sir<<endl;
   strcpy(copie_sir,sir);
   cout<<"Cuvantul inversat "<<strrev(sir)<<endl;
   if(strcmp(copie_sir,sir)==0)
    cout<<"palindrom";
    else
    cout<<"nu este palindrom";
}
