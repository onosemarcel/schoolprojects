#include<fstream>
#include<iostream>
#include<string.h>
using namespace std;
char sir[30],*p, car;
int nr;
ifstream f("text.dat");
int main()
{

   f.get(sir,30);
   f>>car;
   strcpy(sir,strlwr(sir));
   if(isupper(car))
    car=car+32;
   p=strchr(sir,car);
   cout<<"Litera "<<car<<" apare in: "<<endl;
   while(p)
   {
       nr++;
       cout<<"pozitia "<<p-sir+1<<endl;
       p=strchr(p+1, car);
   }
   cout<<"de "<<nr<<" ori";
}


