#include<iostream>
#include<string.h>
using namespace std;
char sir[30],*p;
int main()
{
   cin.get(sir,30);
   int n=strlen(sir);
   for(int i=0;i<n;i++)
    {
        if(sir[i]>=65&&sir[i]<=90)
            sir[i]=sir[i]+32;
    }
   cout<<sir;

}
