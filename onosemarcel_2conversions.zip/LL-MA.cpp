#include<fstream>
#include<iostream>
using namespace std;

int A[100][100],n;

int main()
{int x,y;

    fstream f;
    f.open("input.dat",ios::in);
    f>>n;


    for(int i=0;i<n;i++)
    {
        f>>x;
        for(int j=0;j<n-1;j++)
        {
            f>>y;
            if(y) A[i][y-1]=1;
        }
    }
for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        cout<<A[i][j]<<" ";
        cout<<endl;
    }

    f.close();

}
